xdescribe("UI Transition", function() {

  moduleTests({
    module  : 'transition',
    element : '.ui.image'
  });

});
